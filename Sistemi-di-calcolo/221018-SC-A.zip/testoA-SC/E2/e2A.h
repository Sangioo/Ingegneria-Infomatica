#ifndef __E2__
#define __E2__

int loadStringsFromFile (const char * filename, char *** list);

#endif
