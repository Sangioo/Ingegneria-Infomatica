#ifndef ES1_HEADER
#define ES1_HEADER

#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char* str_to_upper(const char* s);

#endif