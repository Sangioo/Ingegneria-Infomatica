#ifndef ES1_HEADER
#define ES1_HEADER

#include <stdlib.h>
#include <ctype.h>

int* strings_are_upper(const char** array, int n);

#endif