#ifndef __E2__
#define __E2__

void decodeTextFile(const char * encoded_file, const char * key, char ** decoded_text);

#endif
