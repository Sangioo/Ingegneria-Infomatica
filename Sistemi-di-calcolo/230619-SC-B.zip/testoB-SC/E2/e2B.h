#ifndef __E2__
#define __E2__

int getBalanceMovements(const char*, int, int, int *);

#endif
