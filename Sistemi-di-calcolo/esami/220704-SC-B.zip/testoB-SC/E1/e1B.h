#ifndef ES1_HEADER
#define ES1_HEADER

#include <string.h>
#include <stdlib.h>

int count_matching_vars(char** vars, char* pattern);

#endif