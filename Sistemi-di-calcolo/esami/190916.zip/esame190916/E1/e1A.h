#ifndef __E1__
#define __E1__

int is_prefix(const char* s, const char* t);

#endif
