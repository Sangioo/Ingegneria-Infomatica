#include "e.h"

#define PROMPT "SC> "

int main() {
    return do_shell(PROMPT);
}
