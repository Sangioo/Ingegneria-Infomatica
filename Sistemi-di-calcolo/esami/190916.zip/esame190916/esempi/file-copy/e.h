#ifndef __FILE_COPY__
#define __FILE_COPY__

int copy(const char* src, const char* dst);

#endif

