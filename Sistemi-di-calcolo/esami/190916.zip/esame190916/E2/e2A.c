#include "e2A.h"

void multi_get_env(const char** names, char*** values, int num) {
    // scrivi la soluzione qui...
}
