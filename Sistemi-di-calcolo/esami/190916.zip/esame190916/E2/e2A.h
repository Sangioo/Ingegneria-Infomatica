#ifndef __E2__
#define __E2__

void multi_get_env(const char** names, char*** values, int num);

#endif
