#ifndef ES1_HEADER
#define ES1_HEADER

#include <string.h>
#include <stdlib.h>

unsigned int* div_vectors(unsigned int* a, unsigned int* b, int n);

#endif