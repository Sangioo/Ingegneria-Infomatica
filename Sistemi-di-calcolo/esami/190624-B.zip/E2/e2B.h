#ifndef __E2__
#define __E2__

void make_files(int n, void (*f)(int i, char name[64], char buf[256]));

#endif
