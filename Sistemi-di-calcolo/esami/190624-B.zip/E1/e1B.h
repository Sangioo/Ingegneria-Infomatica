#ifndef __E1__
#define __E1__

int has_duplicates(short* v, unsigned n);

#endif
