#ifndef __E2__
#define __E2__

int contains(char* s, char c, int n);

#endif
