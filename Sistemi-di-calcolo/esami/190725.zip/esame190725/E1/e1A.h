#ifndef __E1__
#define __E1__

int most_freq_char(const char* s, int* map);
void clear(int* map, int n);

#endif
