#ifndef __E2__
#define __E2__

int wordcount(const char** s, int n);

#endif
