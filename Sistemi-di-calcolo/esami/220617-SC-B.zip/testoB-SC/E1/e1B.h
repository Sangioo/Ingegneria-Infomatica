#ifndef ES1_HEADER
#define ES1_HEADER

int crc32b(char *bytes, int n);
void get_constant(int* value, int index);

#endif