#ifndef __E2__
#define __E2__
#include <unistd.h>

off_t searchfile(char* filename, char c);

#endif
