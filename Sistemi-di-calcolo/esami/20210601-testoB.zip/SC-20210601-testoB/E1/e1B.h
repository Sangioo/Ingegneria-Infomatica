#ifndef E1B_H
#define E1B_H

unsigned int adler32_simplified(unsigned char* data, int len);

#endif
