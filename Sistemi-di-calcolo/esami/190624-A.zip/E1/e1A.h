#ifndef __E1__
#define __E1__

void init_matrix(short** m, unsigned n);
short value(unsigned i, unsigned j);

#endif
