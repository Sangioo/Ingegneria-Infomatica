#ifndef __E2__
#define __E2__

void run(int* v, int n, int (*f)(int i));

#endif
