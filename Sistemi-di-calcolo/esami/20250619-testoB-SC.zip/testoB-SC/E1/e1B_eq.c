// Inserire il C equivalente qui (opzionale: non concorre alla valutazione)
#include "e1B.h"

