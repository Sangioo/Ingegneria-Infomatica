#ifndef __E2__
#define __E2__

#define MAX_PARAGRAPHS 1024
#define MAX_PARAGRAPH_LEN 10000
#define MAX_LINE_LEN 1024

void frasePiuLungaPerParagrafo(const char* nomefile, int* numeroParagrafi, int** lunghezzaFraseMaxPerParagrafo);

#endif
