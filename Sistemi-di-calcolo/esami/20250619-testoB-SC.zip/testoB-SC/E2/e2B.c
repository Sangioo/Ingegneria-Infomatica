#include "e2B.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

// inserisci la soluzione qui...
