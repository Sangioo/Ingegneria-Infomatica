#ifndef __E1__
#define __E1__

#include <stdlib.h>
#include <string.h>

int suffix(const char* a, const char* b);

#endif
