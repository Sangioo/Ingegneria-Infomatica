#ifndef __E2__
#define __E2__

int wordWithMaxCount(const char* text, const char c, char ** word);

#endif
