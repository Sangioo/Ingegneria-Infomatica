#ifndef __E2__
#define __E2__

char* load(const char* filename, unsigned* size);

#endif
