#ifndef __E1__
#define __E1__

#include <stdlib.h>
#include <string.h>

int count_tokens(char* str, const char* sep);

#endif
