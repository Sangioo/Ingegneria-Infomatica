// Inserire di seguito il C equivalente (opzionale: non concorre alla valutazione)
#include "e1A.h"

