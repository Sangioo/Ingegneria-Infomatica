#ifndef __E2__
#define __E2__

#define MAX_PARAGRAFI 1024
#define MAX_PARAGRAFO_LEN 10000
#define MAX_LINE_LEN 1024

void numeroFrasiMaxParagrafi(const char* filename, int* maxNumeroFrasi);

#endif
