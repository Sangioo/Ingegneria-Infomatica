#ifndef ES1_HEADER
#define ES1_HEADER

int crc32(char *bytes, int n);

#endif