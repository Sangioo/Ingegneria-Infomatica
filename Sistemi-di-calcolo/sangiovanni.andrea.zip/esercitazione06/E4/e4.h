#ifndef __LCM__
#define __LCM__

int lcm(int x, int y);

#endif