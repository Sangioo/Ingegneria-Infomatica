#ifndef __E2__
#define __E2__

int examStats(const char*, int *, int *, float *);

#endif
